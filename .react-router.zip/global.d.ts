declare module '*.gql' {
  const value: any
  export default value
}