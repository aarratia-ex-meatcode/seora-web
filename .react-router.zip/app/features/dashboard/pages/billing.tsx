"use client";
export default function BillingPage() {
  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <h1 className="text-3xl font-bold">Billing</h1>
    </div>
  );
}
